import java.util.Random;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] poleHrace = new String[101];
		String[] poleNepritele = new String[101];
		Random rnd = new Random();
		
				
		
String aircraft_carrier="1";
	
	
	

String cruiser="1" ;
String battleship  ="1";		





	String submarine="1";

		

	


	String torpedo_guy="1";	
		Hr�� p1 = new Hr��(aircraft_carrier,battleship,cruiser,submarine,torpedo_guy);
		
		
		
		
		
		
		
		System.out.println("Hern� pole hr��e:");
		System.out.println(" 1  2  3  4  5  6  7  8  9  10");
		for(int i =1;i<poleHrace.length;i++) {
			
			poleHrace[i]="[_]";
			System.out.print(poleHrace[i]);
			if(i==10) {
				System.out.print("A");
			System.out.println();}
			if(i==20) {				System.out.print("B");

				System.out.println();}
			if(i==30) {				System.out.print("C");

				System.out.println();}
			if(i==40) {				System.out.print("D");

				System.out.println();}
			if(i==50) {				System.out.print("E");

				System.out.println();}
			if(i==60) {				System.out.print("F");

				System.out.println();}
			if(i==70) {				System.out.print("G");

				System.out.println();}
			if(i==80) {				System.out.print("H");

				System.out.println();}
			if(i==90) {				System.out.print("CH");

				System.out.println();}
			if(i==100) {				System.out.print("I");

				System.out.println();}
			
		

		}
		
		
		
		System.out.println();
		System.out.println("Hern� pole nep��tele:");
		System.out.println(" 1  2  3  4  5  6  7  8  9  10");
		for(int i =1;i<poleNepritele.length;i++) {
			poleNepritele[i]="[_]";
			System.out.print(poleNepritele[i]);

			if(i==10) {System.out.print("A");
			System.out.println();}
			if(i==20) {System.out.print("B");
				System.out.println();}
			if(i==30) {System.out.print("C");
				System.out.println();}
			if(i==40) {System.out.print("D");
				System.out.println();}
			if(i==50) {System.out.print("E");
				System.out.println();}
			if(i==60) {System.out.print("F");
				System.out.println();}
			if(i==70) {System.out.print("G");
				System.out.println();}
			if(i==80) {System.out.print("H");
				System.out.println();}
			if(i==90) {System.out.print("CH");
				System.out.println();}
			if(i==100) {System.out.print("I");
				System.out.println();}
			

		}
		
		
		
				
	
			
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	

}
