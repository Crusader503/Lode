import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int velikost=10;
		int[][] poleHrace = new int[velikost][velikost];
		int[][] poleNepritele = new int[velikost][velikost];
		Random rnd = new Random();
		Scanner scr=new Scanner(System.in);
		
		
	
			
			
			for(int delkapole =0;delkapole<poleHrace.length;delkapole++) {
			
			for(int sirkapole =0;sirkapole<poleHrace[delkapole].length;sirkapole++) {
				
				poleHrace[delkapole][sirkapole]=0;
		
				
			}}
			
			
			int aircraft_carrier=5;
			int cruiser=4 ;
			int battleship  =3;	
		    int submarine=1;
            int torpedo_guy=2;	
            int aircraft_carrier2=5;
			int cruiser2=4 ;
			int battleship2  =3;	
		   
            int torpedo_guy2=2;	
            
	Hr�� p1 = new Hr��(aircraft_carrier,battleship,cruiser,submarine,torpedo_guy);
	Nep��tel n1 = new Nep��tel (aircraft_carrier,battleship,cruiser,submarine,torpedo_guy);
	Hr�� p2 = new Hr��(aircraft_carrier2,battleship2,cruiser2,submarine,torpedo_guy2);
	Nep��tel n2 = new Nep��tel (aircraft_carrier2,battleship2,cruiser2,submarine,torpedo_guy2);
			//ponorka u hr��e
			for(int i = 0;i<1;i++) {
				int d1=rnd.nextInt(poleHrace.length);
				int s1=rnd.nextInt(poleHrace.length);
				
				
				
				System.out.print("Sou�adnice ponorky: ");
				System.out.print(d1+",");
				System.out.println(s1);

				poleHrace[d1][s1]=p1.getSubmarine();			
				//System.out.println(poleHrace[d1][s1]);	

			}
			//ponorka u nepritele
			for(int i = 0;i<1;i++) {
				int d1=rnd.nextInt(poleNepritele.length);
				int s1=rnd.nextInt(poleNepritele.length);
				String ikona="x";
				poleNepritele[d1][s1]=n1.getSubmarine();
				System.out.println(d1);
				System.out.println(s1);

			}
			//torp�doborec hr��e(torpedo_guy)
			for(int i = 0;i<1;i++) {
				int d2=rnd.nextInt(poleHrace.length);
				int s2=rnd.nextInt(poleHrace.length);
				poleNepritele[d2][s2]=p1.getTorpedo_guy();
				System.out.print("Sou�adnice torp�doborce: ");
				System.out.print(d2+",");
				System.out.println(s2);
				}
			//torpedo_guy u nepritele
			for(int i = 0;i<1;i++) {
				int d2=rnd.nextInt(poleNepritele.length);
				int s2=rnd.nextInt(poleNepritele.length);
				poleNepritele[d2][s2]=n1.getTorpedo_guy();
				
				
				
				
				
				poleNepritele[d2+1][s2]=n2.getTorpedo_guy();
				System.out.println(d2);
				System.out.println(s2);
				}
			
			
			
			
			
			
			
			int typ = 0;
			int hit=1;
			//zad�v�n� souradnic
			int LodeNepritele= 2;
			while(LodeNepritele>0) {
				while(hit==1) {
			System.out.println("Zadej souradnice x");
			int x = scr.nextInt();
			System.out.println("Zadej souradnice y");
			int y = scr.nextInt();
			
			int posledni_x=x;
			int posledni_y=y;
			
			
			if(poleNepritele[x][y]==n1.getSubmarine()) {
				typ=2;
				poleNepritele[x][y]=0;
				
				}
			scr.nextLine();
			if(poleNepritele[x][y]==n2.getTorpedo_guy()) {
				typ=1;
				poleNepritele[x][y]=0;
				
			}
			if(poleNepritele[x][y]==n1.getTorpedo_guy())	 {
				typ = 1;
				poleNepritele[x][y]=0;
				}
				if(poleNepritele[x][y]==0) {
					typ=2;
				}
				
				
				scr.nextLine();
			
				
			//z�sah
			if(typ==0) {
				System.out.println("Minul");
				hit=0;
			}if(typ==1) {
				System.out.println("Z�sah");
				hit=1;
				
			}if(typ==2) {
				System.out.println("Lod znicena");
				LodeNepritele--;
				hit=1;
				
			}
			

			typ= 0;
			System.out.println("Zb�vaj�c� lod�: "+LodeNepritele);
			
				}
			
			
			
		
		
		}
				scr.close();
	if(LodeNepritele==0){
		System.out.print("Vyhr�l jsi");
	}
			
	
		
		
		
		
		
		
		
		
		
		
		
		}
		
		
		

	

}
