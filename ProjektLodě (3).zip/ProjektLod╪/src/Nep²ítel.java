
public class Nep��tel {
	private int aircraft_carrier;
	private int battleship;
	private int cruiser;
	private int submarine;
	private int torpedo_guy;
	
	
	
	
	
	
	public Nep��tel(int aircraft_carrier, int battleship, int cruiser, int submarine, int torpedo_guy) {
		
		this.aircraft_carrier = aircraft_carrier;
		this.battleship = battleship;
		this.cruiser = cruiser;
		this.submarine = submarine;
		this.torpedo_guy = torpedo_guy;
	}
	public int getAircraft_carrier() {
		return aircraft_carrier;
	}
	public void setAircraft_carrier(int aircraft_carrier) {
		this.aircraft_carrier = aircraft_carrier;
	}
	public int getBattleship() {
		return battleship;
	}
	public void setBattleship(int battleship) {
		this.battleship = battleship;
	}
	public int getCruiser() {
		return cruiser;
	}
	public void setCruiser(int cruiser) {
		this.cruiser = cruiser;
	}
	public int getSubmarine() {
		return submarine;
	}
	public void setSubmarine(int submarine) {
		this.submarine = submarine;
	}
	public int getTorpedo_guy() {
		return torpedo_guy;
	}
	public void setTorpedo_guy(int torpedo_guy) {
		this.torpedo_guy = torpedo_guy;
	}
	
	
}