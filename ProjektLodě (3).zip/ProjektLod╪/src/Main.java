import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int velikost=10;
		int[][] poleHrace = new int[velikost][velikost];
		int[][] poleNepritele = new int[velikost][velikost];
		Random rnd = new Random();
		Scanner scr=new Scanner(System.in);
		
		
	
			
			
			for(int delkapole =0;delkapole<poleHrace.length;delkapole++) {
			
			for(int sirkapole =0;sirkapole<poleHrace[delkapole].length;sirkapole++) {
				
				poleHrace[delkapole][sirkapole]=0;
		
				
			}
			
			
			int aircraft_carrier=1;
			int cruiser=1 ;
			int battleship  =1;	
		    int submarine=1;
            int torpedo_guy=1;	
            
	Hr�� p1 = new Hr��(aircraft_carrier,battleship,cruiser,submarine,torpedo_guy);
	Nep��tel n1 = new Nep��tel (aircraft_carrier,battleship,cruiser,submarine,torpedo_guy);	
			//ponorka u hr��e
			for(int i = 0;i<1;i++) {
				int d1=rnd.nextInt(poleHrace.length);
				int s1=rnd.nextInt(poleHrace.length);
				
				
				
				System.out.print("Sou�adnice ponorky: ");
				System.out.print(d1+",");
				System.out.println(s1);

				poleHrace[d1][s1]=p1.getSubmarine();			
				//System.out.println(poleHrace[d1][s1]);	

			}
			//ponorka u nepritele
			for(int i = 0;i<1;i++) {
				int d1=rnd.nextInt(poleNepritele.length);
				int s1=rnd.nextInt(poleNepritele.length);
				String ikona="x";
				poleNepritele[d1][s1]=n1.getSubmarine();
				System.out.println(d1);
				System.out.println(s1);

			}
			//torp�doborec hr��e(torpedo_guy)
			for(int i = 0;i<1;i++) {
				int d2=rnd.nextInt(poleHrace.length);
				int s2=rnd.nextInt(poleHrace.length);
				String ikona="x";
				poleNepritele[d2][s2]=p1.getTorpedo_guy();
				System.out.print("Sou�adnice torp�doborce: ");
				System.out.print(d2+",");
				System.out.println(s2);
				}
			//torpedo_guy u nepritele
			for(int i = 0;i<1;i++) {
				int d2=rnd.nextInt(poleNepritele.length);
				int s2=rnd.nextInt(poleNepritele.length);
				String ikona="x";
				poleNepritele[d2][s2]=n1.getTorpedo_guy();
				System.out.println(d2);
				System.out.println(s2);
				}
			
			
			
			
			
			
			
			
			
			//zad�v�n� souradnic
			int turn= 1;
			while(turn==1) {
			System.out.println("Zadej souradnice x");
			int x = scr.nextInt();
			System.out.println("Zadej souradnice y");
			int y = scr.nextInt();
			int typ = 0;
			if(poleNepritele[x][y]==n1.getSubmarine()) {
				typ = 2;
				
				}
			
			if(poleNepritele[x][y]==n1.getTorpedo_guy()) {
				typ = 1;
				poleNepritele[x+1][y]=n1.getTorpedo_guy();
				}
			
				
			//z�sah
			if(typ==0) {
				System.out.println("Minul");
				turn= 0;
			}if(typ==1) {
				System.out.println("Z�sah");
				turn= 1;
			}
			if(typ==2) {
				System.out.println("Lod znicena");
				turn= 1;
				
				
			}

			typ= 0;
			
			}
			
			
		
		
		
				
	
			
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	

}}
