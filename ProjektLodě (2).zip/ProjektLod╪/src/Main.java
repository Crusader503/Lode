import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int velikost=10;
		String[][] poleHrace = new String[velikost][velikost];
		String[][] poleNepritele = new String[velikost][velikost];
		Random rnd = new Random();
		Scanner scr=new Scanner(System.in);
		
		//aircraft_carrier
	
			int x1= rnd.nextInt(poleHrace.length);
			int y1 = rnd.nextInt(poleHrace.length);
			
			for(int delkapole =0;delkapole<poleHrace.length;delkapole++) {
			
			for(int sirkapole =0;sirkapole<poleHrace[delkapole].length;sirkapole++) {
				
				poleHrace[delkapole][sirkapole]="-";
		
				
			}
			
			
			String aircraft_carrier="1";
			String cruiser="1" ;
			String battleship  ="1";	
		    String submarine="X";
            String torpedo_guy="1";	
	Hr�� p1 = new Hr��(aircraft_carrier,battleship,cruiser,submarine,torpedo_guy);
			
			//prvni lod u hr��e
			for(int i = 0;i<1;i++) {
				int d1=rnd.nextInt(poleHrace.length);
				int s1=rnd.nextInt(poleHrace.length);
				
				
				
				System.out.print("Sou�adnice ponorky: ");
				System.out.print(d1+",");
				System.out.println(s1);

				poleHrace[d1][s1]=p1.getSubmarine();			
				//System.out.println(poleHrace[d1][s1]);	

			}
			//prvni lod u nepritele
			for(int i = 0;i<1;i++) {
				int d1=rnd.nextInt(poleNepritele.length);
				int s1=rnd.nextInt(poleNepritele.length);
				String ikona="x";
				poleNepritele[d1][s1]=p1.getSubmarine();
				System.out.println(d1);
				System.out.println(s1);

			}
			
			//zad�v�n� souradnic
			int lode = 5;
			while((lode=<5) || (lode>0)) {
			System.out.println("Zadej souradnice x");
			int x = scr.nextInt();
			System.out.println("Zadej souradnice y");
			int y = scr.nextInt();
			if(poleNepritele[x][y]==p1.getSubmarine()) {
				System.out.println("Z�sah");
				lode=lode-1;
			}if(poleNepritele[x][y]!=p1.getSubmarine()) {
				System.out.println("Minul");
			}
			
			
			
			System.out.println(lode);
		}

			/*for(int delkapole =0;delkapole<poleNepritele.length;delkapole++) {
			
			for(int sirkapole =0;sirkapole<poleNepritele[delkapole].length;sirkapole++) {
				
				poleNepritele[delkapole][sirkapole]="-";
				
				
				
			}
			
			
		}
		
        */
		
		

			
			
			
			
			
			
			
			
			
			
			
			
			
			
		
		
	/*System.out.println("Hern� pole hr��e:");
		System.out.println(" 1  2  3  4  5  6  7  8  9  10");
		for(int i =1;i<poleHrace.length;i++) {
			
			System.out.println(poleHrace[i]);
			
			/*if(i==10) {
				System.out.print("1");
			System.out.println();}
			if(i==20) {				System.out.print("2");

				System.out.println();}
			if(i==30) {				System.out.print("3");

				System.out.println();}
			if(i==40) {				System.out.print("4");

				System.out.println();}
			if(i==50) {				System.out.print("5");

				System.out.println();}
			if(i==60) {				System.out.print("6");

				System.out.println();}
			if(i==70) {				System.out.print("7");

				System.out.println();}
			if(i==80) {				System.out.print("8");

				System.out.println();}
			if(i==90) {				System.out.print("9");

				System.out.println();}
			if(i==100) {				System.out.print("10");

				System.out.println();}
			*/
		

		/*}

		
		
		System.out.println();
		System.out.println("Hern� pole nep��tele:");
		System.out.println(" 1  2  3  4  5  6  7  8  9  10");
		for(int i =1;i<101;i++) {
			
			System.out.print("[ ]");

			if(i==10) {System.out.print("1");
			System.out.println();}
			if(i==20) {System.out.print("2");
				System.out.println();}
			if(i==30) {System.out.print("3");
				System.out.println();}
			if(i==40) {System.out.print("4");
				System.out.println();}
			if(i==50) {System.out.print("5");
				System.out.println();}
			if(i==60) {System.out.print("6");
				System.out.println();}
			if(i==70) {System.out.print("7");
				System.out.println();}
			if(i==80) {System.out.print("8");
				System.out.println();}
			if(i==90) {System.out.print("9");
				System.out.println();}
			if(i==100) {System.out.print("10");
				System.out.println();}
			

		}
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
				
		
/*String aircraft_carrier="1";
	
	
	

String cruiser="1" ;
String battleship  ="1";		





	String submarine="1";

		

	


	String torpedo_guy="1";	
		Hr�� p1 = new Hr��(aircraft_carrier,battleship,cruiser,submarine,torpedo_guy);*/
		
		
		
		
		
		
		
		
		
		
		
				
	
			
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	

}}
