
public class Hr�� {
	
	private String aircraft_carrier;
	private String battleship;
	private String cruiser;
	private String submarine;
	private String torpedo_guy;
	
	
	Hr��(String ac,String b,String c,String s, String tg){
		this.aircraft_carrier=ac;
		this.battleship=b;
		this.cruiser=c;
		this.submarine=s;
		this.torpedo_guy=tg;
		
	
		
	}
	
	
	
	
	
	
	public String getAircraft_carrier() {
		return aircraft_carrier;
	}
	public void setAircraft_carrier(String aircraft_carrier) {
		this.aircraft_carrier = aircraft_carrier;
	}
	public String getBattleship() {
		return battleship;
	}
	public void setBattleship(String battleship) {
		this.battleship = battleship;
	}
	public String getCruiser() {
		return cruiser;
	}
	public void setCruiser(String cruiser) {
		this.cruiser = cruiser;
	}
	public String getSubmarine() {
		return submarine;
	}
	public void setSubmarine(String submarine) {
		this.submarine = submarine;
	}
	public String getTorpedo_guy() {
		return torpedo_guy;
	}
	public void setTorpedo_guy(String torpedo_guy) {
		this.torpedo_guy = torpedo_guy;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
